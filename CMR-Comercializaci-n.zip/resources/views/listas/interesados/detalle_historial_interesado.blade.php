@extends('layout')
@section('title', 'Lista de clientes')
@section('pagina', 'Clientes')
@section('content')
    
@endsection