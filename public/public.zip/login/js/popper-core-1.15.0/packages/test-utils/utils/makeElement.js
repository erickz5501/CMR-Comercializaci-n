/**
 * Create an element.
 */
export default function makeElement() {
  return document.createElement('div');
}
