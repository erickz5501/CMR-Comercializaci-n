function modal_medios(){
    $('#registroModalMedio').modal('show');
}

function modal_cotizacion(){
    limpiar_cotizacion();
    $('#registroModalCotizacion').modal('show');
}